#
# Configuration file for using the xslt library
#
XSLT_LIBDIR="-L/usr/lib"
XSLT_LIBS="-lxslt  -L/usr/lib -lxml2 -lz -lpthread -liconv -lm  "
XSLT_INCLUDEDIR="-I/usr/include"
MODULE_VERSION="xslt-1.1.28"
