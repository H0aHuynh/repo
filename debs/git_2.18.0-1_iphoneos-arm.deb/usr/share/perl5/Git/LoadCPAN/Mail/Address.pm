package Git::LoadCPAN::Mail::Address;
use 5.008;
use strict;
use warnings;
use Git::LoadCPAN (
	module => 'Mail::Address',
	import => 0,
);

1;
