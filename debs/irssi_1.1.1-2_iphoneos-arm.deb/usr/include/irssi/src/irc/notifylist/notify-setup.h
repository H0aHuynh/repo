#ifndef __NOTIFY_SETUP_H
#define __NOTIFY_SETUP_H

void notifylist_add_config(NOTIFYLIST_REC *rec);
void notifylist_remove_config(NOTIFYLIST_REC *rec);

void notifylist_read_config(void);

#endif
